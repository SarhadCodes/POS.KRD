═══════════════════════════════════════════════════════
           POS.KRD - Point of Sale System
                Professional Edition
═══════════════════════════════════════════════════════

📦 INSTALLATION INSTRUCTIONS:
─────────────────────────────────────────────────────

1. Double-click "POS.KRD Setup.exe"
2. Choose your installation location
3. Select "Create desktop shortcut" (recommended)
4. Click "Install"
5. Launch the application


🔑 DEFAULT LOGIN CREDENTIALS:
─────────────────────────────────────────────────────

Manager Account:
   Email: admin@pos.com
   Password: admin123

Cashier Account:
   Email: cashier@pos.com
   Password: cashier123

⚠️ IMPORTANT: Change these passwords after first login!


✨ FEATURES:
─────────────────────────────────────────────────────

✅ Complete POS system with cashier and manager roles
✅ Product management with barcode support
✅ Inventory tracking with low stock alerts
✅ Product expiration date monitoring
✅ Sales reporting and analytics
✅ Debt management system
✅ Virtual keyboard for touchscreen devices
✅ Multi-language support (English/Kurdish)
✅ Database backup and restore
✅ Offline operation (no internet required)
✅ Multi-window cashier support
✅ Professional branding with custom logo


📋 SYSTEM REQUIREMENTS:
─────────────────────────────────────────────────────

• Windows 7/8/10/11 (64-bit)
• 2GB RAM minimum
• 200MB free disk space
• No internet connection required


🚀 GETTING STARTED:
─────────────────────────────────────────────────────

1. Login with manager account (admin@pos.com)
2. Go to "Products" and add your items
3. Create additional cashier users if needed
4. Start selling!


💡 TIPS:
─────────────────────────────────────────────────────

• Connect a barcode scanner for faster checkout
• Use the backup feature regularly
• Set product expiration dates to track freshness
• Create multiple cashier accounts for staff
• Use the debt management system for credit sales


📧 SUPPORT: sarhadyt@gmail.com
─────────────────────────────────────────────────────

For support or questions, contact your system provider.

═══════════════════════════════════════════════════════
              © 2025 POS.KRD - All Rights Reserved
═══════════════════════════════════════════════════════

